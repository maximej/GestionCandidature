package com.GeekJob.concoursDEV;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControllerConcours {

	@Autowired
	private ConcoursService service; 
	
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		//List<concours> listConcours = service.listAll();
		//model.addAttribute("listConcours", listConcours);
		return "index";
	}

	@RequestMapping("/concoursListe")
	public String viewListeConcours(Model model) {
		List<concours> listConcours = service.listAll();
		model.addAttribute("listConcours", listConcours);
		return "ConcoursListBack";
	}
	
	@RequestMapping("/concoursListecadidat")
	public String viewListeConcourfront(Model model) {
		List<concours> listConcours = service.listAll();
		model.addAttribute("listConcours", listConcours);
		return "ConcoursListFront";
	}
	
	@RequestMapping("/details/{id}")
	public ModelAndView detailsConcours(@PathVariable(name = "id") int id ) {
		ModelAndView mav = new ModelAndView("detailsConcours");
		concours concoursDemande = service.get(id);
		mav.addObject("concoursDemande", concoursDemande);
		
		//Conversion de blob au image
		java.sql.Blob blob = concoursDemande.getImage_css();  
			InputStream in;
			try {
				in = blob.getBinaryStream();
				BufferedImage img = ImageIO.read(in);
				File outputfile = new File("image.jpg");
				ImageIO.write(img, "jpg", outputfile);
				mav.addObject("concoursImage", outputfile.getName());
			} catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
		return mav;
	}
	
	
}
