package com.GeekJob.concoursDEV;

import org.springframework.data.jpa.repository.JpaRepository;


public interface ConcoursI extends JpaRepository<concours, Integer> {

}
