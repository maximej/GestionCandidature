package com.GeekJob.concoursDEV;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcoursDevApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcoursDevApplication.class, args);
	}

}
